//
//  CustomAnnoationView.h
//  MAPVIEWMUTILPLE
//
//  Created by Alet Viegas on 5/1/15.
//  Copyright (c) 2015 Dipak. All rights reserved.
//

#import <MapKit/MapKit.h>
#import <Foundation/Foundation.h>

@interface CustomAnnoationView : MKAnnotationView
{
    CLLocationCoordinate2D coordinate;
    NSString *title;
    NSString *subtitle;
    
}



@property(nonatomic,assign)CLLocationCoordinate2D coordinate;
@property(nonatomic,copy) NSString *title ,*subtitle;
-(id)initAnnotationWithImage:(id<MKAnnotation>)annotation reuseIdentiFier:(NSString *)reuserIdentifier annotationViewImage:(UIImage *)anonViewImage;
@end
