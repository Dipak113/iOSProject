//
//  CustomAnnoationView.m
//  MAPVIEWMUTILPLE
//
//  Created by Alet Viegas on 5/1/15.
//  Copyright (c) 2015 Dipak. All rights reserved.
//

#import "CustomAnnoationView.h"

@implementation CustomAnnoationView
@synthesize subtitle,title,coordinate;

-(id)initAnnotationWithImage:(id<MKAnnotation>)annotation reuseIdentiFier:(NSString *)reuserIdentifier annotationViewImage:(UIImage *)anonViewImage
{
    self = [super initWithAnnotation:annotation reuseIdentifier:reuserIdentifier];
    
    self.image = anonViewImage;

    return  self;

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
