//
//  GetPinViewController.m
//  MAPVIEWMUTILPLE
//
//  Created by Alet Viegas on 4/13/15.
//  Copyright (c) 2015 Dipak. All rights reserved.
//

#import "GetPinViewController.h"
#import "ViewController.h"
#define Kothrud_LATITUDE   18.520510;
#define kothrud_LONGITUDE  73.856733;
#define kothrudr_LATITUDE  18.5086716;
#define kothrudr_LONGITUDE 73.8124927;

@interface GetPinViewController ()
{

    NSString *str;
    NSString*strin;
    

}
@end

@implementation GetPinViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    int foo = 123; // This is an integer variable
    int *ptr = &foo; // This is a pointer to an integer variable
    
    
    NSLog(@"%d",*ptr);
    double kothrudlatitutde =  Kothrud_LATITUDE;
    double kothrudlongitude =  kothrud_LONGITUDE;
    

strin = [NSString stringWithFormat:@"%lf",kothrudlatitutde];
    str = [NSString stringWithFormat:@"%lf",kothrudlongitude];
    NSLog(@"%@",str);
    NSLog(@"%@",strin);
    
};

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)GetPinTap:(id)sender
{
    ViewController* sec =[self.storyboard instantiateViewControllerWithIdentifier:@"cell"];
    
    
   
   
    sec.str1= str;
    sec.str2 = strin;
    
            [self.navigationController pushViewController:sec animated:YES];
    
            
            //sec.img1=img;
            //sec.imageview.image=[img objectAtIndex:i];
            
            //imageView.image = img;
            
    
        
        

    
    

    
    
    
    
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
