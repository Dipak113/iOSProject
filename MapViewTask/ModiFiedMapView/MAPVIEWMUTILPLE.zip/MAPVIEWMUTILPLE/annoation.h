//
//  annoation.h
//  MAPVIEWMUTILPLE
//
//  Created by Dipak on 3/21/14.
//  Copyright (c) 2014 Dipak. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MKAnnotation.h>

@interface annoation :NSObject <MKAnnotation>
{
    CLLocationCoordinate2D coordinate;
    NSString *title;
    NSString *subtitle;
    
}
@property(nonatomic,assign)CLLocationCoordinate2D coordinate;
@property(nonatomic,copy) NSString *title ,*subtitle;

@end
