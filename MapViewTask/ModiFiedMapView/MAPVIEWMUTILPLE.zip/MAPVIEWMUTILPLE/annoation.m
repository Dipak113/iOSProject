//
//  annoation.m
//  MAPVIEWMUTILPLE
//
//  Created by Dipak on 3/21/14.
//  Copyright (c) 2014 Dipak. All rights reserved.
//

#import "annoation.h"

@interface annoation ()

@end

@implementation annoation
@synthesize subtitle,title,coordinate;
@end
