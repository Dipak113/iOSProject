//
//  ViewController.m
//  MAPVIEWMUTILPLE
//
//  Created by Dipak on 3/21/14.
//  Copyright (c) 2014 Dipak. All rights reserved.
//

#import "ViewController.h"
#import "annoation.h"

#define Kothrud_LATITUDE   18.520510;
#define kothrud_LONGITUDE  73.856733;
#define kothrudr_LATITUDE  18.5086716;
#define kothrudr_LONGITUDE 73.8124927;
@interface ViewController ()
@property(nonatomic,retain) IBOutlet  MKMapView *map;
@end
// city coordinates

//span
#define the_span 0.10f;
@implementation ViewController

@synthesize mapView,str1,str2;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    
    MKCoordinateRegion region;
    CLLocationCoordinate2D center;
    //center
    center.latitude =  Kothrud_LATITUDE;
    center.longitude=  kothrud_LONGITUDE;
    //span
    MKCoordinateSpan span;
    span.latitudeDelta = the_span;
    span.longitudeDelta  =the_span;
    //[mapView setRegion:region];
    region.center = center;
    region.span = span;
    
    //setout map view
    [mapView setRegion:region animated:YES];
    [mapView setCenterCoordinate:mapView.userLocation.location.coordinate animated:YES];
    mapView.showsUserLocation = YES;
    
   /* region.center.latitude = 18.5086716;
    region.center.longitude=  73.8124927;
    region.span.latitudeDelta = 0.5;
    region.span.longitudeDelta  =0.5;
    [mapView setRegion:region];*/
    
    //using array store location
    NSMutableArray * locations = [[NSMutableArray alloc]init];
    CLLocationCoordinate2D location;
    annoation * ann;
    
    //kothrud
    double latdouble = [str2 doubleValue];
    double londouble = [str1 doubleValue];
    NSLog(@"%@",str2);
     NSLog(@"%@",str1);
    
    
    
  
    ann = [[annoation alloc]init];
    location.latitude = latdouble;
    location.longitude = londouble;
    ann.coordinate = location;
    ann.title = @"Nashik";
    ann.subtitle =@"Malegaon";
    [locations addObject:ann];
    
    
    //kothrudr
    ann = [[annoation alloc]init];
    location.latitude = kothrudr_LATITUDE;
    location.longitude = kothrudr_LONGITUDE;
    ann.coordinate = location;
    ann.title = @"kothrudr";
    ann.subtitle =@"pune";
    [locations addObject:ann];
    

    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    [[self.mapView viewForAnnotation:point] setTag:1];
    UIImage *image = [UIImage imageNamed:@"newpin.png"];
    [[self.mapView viewForAnnotation:point] setImage:image];
    
   /* annoation * ann = [[annoation alloc]init];
    ann.title = @"Pune";
    ann.subtitle = @"Kothrud";
    ann.coordinate =  region.center;
    [mapView addAnnotation:ann];*/
    [self.mapView addAnnotations:locations];
    
    
}
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 2000, 2000);
    [_map setRegion:[_map regionThatFits:region] animated:YES];
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView1 viewForAnnotation:(id <MKAnnotation>)annotation
{
    NSString *pinidentifier= @"ann";
    MKPinAnnotationView *pinView = (MKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:pinidentifier];
    if (pinView == nil)
    {
        pinView = [[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:pinidentifier];
        
        pinView.pinColor = MKPinAnnotationColorGreen;
        
        pinView.canShowCallout = YES;
        pinView.animatesDrop = YES;
        pinView.draggable = YES;
        
        
 
        UIButton *btn = [[UIButton alloc]init];
        btn = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        btn.frame = CGRectMake(0, 0, 20, 20);
        
        
//        UILabel *priceLabel = [[UILabel alloc] init];
//        [priceLabel setText:@"Hiee"];
//        CGRect priceFrame = CGRectMake(pinView.bounds.origin.x+5,
//                                       pinView.bounds.origin.y+5 ,
//                                       pinView.bounds.size.width-10,
//                                       pinView.bounds.size.height/2);
//        [priceLabel setFrame:priceFrame];
//        [priceLabel setAdjustsFontSizeToFitWidth:YES];
//        [priceLabel setTextColor:[UIColor greenColor]];
//               [pinView addSubview:priceLabel];
        
        pinView.rightCalloutAccessoryView = btn;
    }
    return pinView;
    
    
}








- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
