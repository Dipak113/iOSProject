//
//  ViewController.h
//  MAPVIEWMUTILPLE
//
//  Created by Dipak on 3/21/14.
//  Copyright (c) 2014 Dipak. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface ViewController : UIViewController<MKMapViewDelegate>
{
    MKMapView *mapView;

}
@property(nonatomic,retain) IBOutlet NSString * str1;
@property(nonatomic,retain) IBOutlet NSString * str2;
@property(nonatomic,retain) IBOutlet MKMapView *mapView;
@end
