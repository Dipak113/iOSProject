//
//  GetPinViewController.h
//  MAPVIEWMUTILPLE
//
//  Created by Alet Viegas on 4/13/15.
//  Copyright (c) 2015 Dipak. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetPinViewController : UIViewController

@end
